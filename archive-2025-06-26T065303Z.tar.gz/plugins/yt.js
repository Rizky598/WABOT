const axios = require('axios');

module.exports = async function(sock, sender, command, key) {

    if (!command.toLowerCase().startsWith('yt ')) return;

    const url = command.split(' ')[1];

    if (!url || !url.includes('youtube.com') && !url.includes('youtu.be')) {

        return await sock.sendMessage(sender, {

            text: '❌ Kirim link YouTube yang valid.\nContoh:\nyt https://youtu.be/xyz',

            quoted: key

        });

    }

    try {

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        const res = await axios.get(`https://api.dlpanda.com/api/dl?url=${encodeURIComponent(url)}`);

        const result = res.data.result || res.data;

        if (!result.video || !result.video.includes('.mp4')) {

            throw new Error('Video tidak tersedia.');

        }

        await sock.sendMessage(sender, {

            video: { url: result.video },

            mimetype: 'video/mp4',

            caption: '✅ Video YouTube berhasil diunduh.',

            quoted: key

        });

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('YT Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengunduh video YouTube.',

            quoted: key

        });

    }

};