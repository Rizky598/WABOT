function delay(ms) {

    return new Promise(resolve => setTimeout(resolve, ms));

}

module.exports = async function(sock, sender, command, key, message) {

    if (!command.toLowerCase().startsWith('h ')) return;

    const isi = command.slice(2).trim();

    if (!isi) {

        return await sock.sendMessage(sender, {

            text: '❌ Harap ketik sesuatu setelah huruf *h*.',

            quoted: key

        });

    }

    // ⏳ Animasi Loading

    const loading = await sock.sendMessage(sender, {

        text: '*ʏᴀɴɢ ꜱᴀʙᴀʀ ʏᴀ ʟᴀᴘᴇᴛ😗*\n█▒▒▒▒▒▒▒▒▒ 10%💔',

        quoted: key

    });

    await delay(700);

    await sock.sendMessage(sender, { edit: loading.key, text: '*ʏᴀɴɢ ꜱᴀʙᴀʀ ʏᴀ ʟᴀᴘᴇᴛ😗*\n███▒▒▒▒▒▒▒ 30%💔' });

    await delay(700);

    await sock.sendMessage(sender, { edit: loading.key, text: '*ʏᴀɴɢ ꜱᴀʙᴀʀ ʏᴀ ʟᴀᴘᴇᴛ😗*\n█████▒▒▒▒▒ 50%💔' });

    await delay(700);

    await sock.sendMessage(sender, { edit: loading.key, text: '*ʏᴀɴɢ ꜱᴀʙᴀʀ ʏᴀ ʟᴀᴘᴇᴛ😗*\n███████▒▒▒ 70%💔' });

    await delay(700);

    await sock.sendMessage(sender, { edit: loading.key, text: '*ʏᴀɴɢ ꜱᴀʙᴀʀ ʏᴀ ʟᴀᴘᴇᴛ😗*\n██████████ 100%💔' });

    // 🎯 Kirim hasil isi pesannya

    await delay(500);

    await sock.sendMessage(sender, {

        text: isi,

        quoted: key

    });

};