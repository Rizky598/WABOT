const axios = require('axios');

module.exports = async function(sock, sender, command, key, message) {

  if (command.toLowerCase() !== 'adzan') return;

  try {

    await sock.sendMessage(sender, { react: { text: '⏳', key } });

    const now = new Date();

    const y = now.getFullYear();

    const m = String(now.getMonth() + 1).padStart(2, '0');

    const d = String(now.getDate()).padStart(2, '0');

    const locID = '1301'; // Jakarta (untuk Indonesia Barat)

    const url = `https://api.myquran.com/v2/sholat/jadwal/${locID}/${y}/${m}/${d}`;

    const res = await axios.get(url);

    const data = res.data.data;

    const j = data.jadwal;

    const menuText = `

🕌 *Adzan Hari Ini ${data.lokasi}* 🕌

📅 ${j.tanggal}

╭─╼╾─✧─╼╾─╮
│ Subuh    : ${j.subuh}
│ Dzuhur   : ${j.dzuhur}
│ Ashar    : ${j.ashar}
│ Maghrib  : ${j.maghrib}
│ Isya     : ${j.isya}
╰─╼╾─✧─╼╾─╯

💡 *Sholat adalah tiang agama Ingat* *dan jalankan tepat waktu*

`;

    await sock.sendMessage(sender, {

      video: { url: 'https://b.top4top.io/m_3463vstzx0.mp4' },

      caption: menuText,

      mimetype: 'video/mp4',

      gifPlayback: true,

      mentions: [sender]

    });

    await sock.sendMessage(sender, {

      audio: {

        url: 'https://c.top4top.io/m_34633dlf51.mp3'

      },

      mimetype: 'audio/mp4',

      ptt: true

    });

    await sock.sendMessage(sender, { react: { text: '✅', key } });

  } catch (err) {

    console.error('ADZAN Error:', err.message);

    await sock.sendMessage(sender, {

      text: '❌ Gagal mengambil jadwal adzan. Coba ulang.',

      quoted: key

    });

  }

};