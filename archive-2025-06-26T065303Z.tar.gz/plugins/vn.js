const googleTTS = require('google-tts-api');

module.exports = async function(sock, sender, command, key) {

    try {

        const text = command.split(' ').slice(1).join(' ');

        if (!text) {

            return await sock.sendMessage(sender, {

                text: '❌ Kirim teks yang ingin diubah jadi suara.\nContoh: .vn Halo semua!',

                quoted: key

            });

        }

        // Dapatkan URL audio dari Google TTS

        const url = googleTTS.getAudioUrl(text, {

            lang: 'id',

            slow: false,

            host: 'https://translate.google.com',

        });

        // Kirim sebagai VN

        await sock.sendMessage(sender, {

            audio: { url },

            mimetype: 'audio/mp4',

            ptt: true

        });

    } catch (err) {

        console.error(err);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengubah teks menjadi suara.',

            quoted: key

        });

    }

};