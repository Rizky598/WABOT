// plugins/anime.js

const axios = require('axios');

module.exports = async function(sock, sender, command, key, messageEvent) {

    try {

        // 1. React emoji ⏳ (menunjukkan sedang proses)

        await sock.sendMessage(sender, {

            react: {

                text: '⏳',

                key: key

            }

        });

        // 2. Ambil gambar anime dari API

        const response = await axios.get('https://api.waifu.pics/sfw/waifu');

        const imageUrl = response.data.url;

        // 3. Kirim gambar anime ke chat

        await sock.sendMessage(sender, {

            image: { url: imageUrl },

            caption: '*ini anime kesukaan lu lapet😹*'

        });

        // 4. Ganti reaksi ke ✅ (berhasil)

        await sock.sendMessage(sender, {

            react: {

                text: '✅',

                key: key

            }

        });

    } catch (error) {

        console.error(error);

        // 5. Reaksi ❌ jika gagal

        await sock.sendMessage(sender, {

            react: {

                text: '❌',

                key: key

            }

        });

        // 6. Kirim pesan error

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil gambar anime. Coba lagi nanti.'

        });

    }

};