const axios = require('axios');

const cheerio = require('cheerio');

async function tiktok(url) {

    try {

        const params = new URLSearchParams();

        params.set("url", url);

        params.set("hd", "1");

        const response = await axios.post("https://tikwm.com/api/", params, {

            headers: {

                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",

                Cookie: "current_language=en",

                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36"

            }

        });

        const data = response.data.data || {};

        return {

            title: data.title,

            no_watermark: data.play

        };

    } catch (err) {

        throw new Error('Gagal mengambil video dari TikTok.');

    }

}

async function tiktokSlide(url) {

    try {

        const response = await axios.get(`https://dlpanda.com/id?url=${url}&token=G7eRpMaa`);

        const $ = cheerio.load(response.data);

        let images = [];

        $("div.col-md-12 > img").each((i, el) => {

            images.push($(el).attr("src"));

        });

        return images;

    } catch (err) {

        throw new Error('Gagal mengambil slide TikTok.');

    }

}

module.exports = async function(sock, sender, command, key) {

    const url = command.split(' ')[1];

    if (!url || !url.includes('tiktok.com')) {

        return await sock.sendMessage(sender, {

            text: '❌ Link TikTok tidak valid!',

            quoted: key

        });

    }

    try {

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        if (url.includes('/photo/') || url.includes('slide')) {

            const images = await tiktokSlide(url);

            for (let i = 0; i < images.length; i++) {

                await sock.sendMessage(sender, {

                    image: { url: images[i] },

                    caption: `📸 Slide ${i + 1}`

                });

            }

        } else {

            const result = await tiktok(url);

            await sock.sendMessage(sender, {

                video: { url: result.no_watermark },

                caption: `🎬 ${result.title || 'Video TikTok'}`

            });

        }

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('TikTok Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil video TikTok.',

            quoted: key

        });

        await sock.sendMessage(sender, { react: { text: '❌', key } });

    }

};