const Parser = require('rss-parser');

const parser = new Parser();

const axios = require('axios');

async function translate(text) {

  try {

    const res = await axios.post('https://libretranslate.de/translate', {

      q: text,

      source: 'en',

      target: 'id',

      format: 'text'

    }, {

      headers: { 'Content-Type': 'application/json' }

    });

    return res.data.translatedText;

  } catch {

    return text;

  }

}

module.exports = async function(sock, sender, command, key) {

  await sock.sendMessage(sender, { react: { text: '⏳', key } });

  try {

    // GUNAKAN RSS CNBC yang valid

    const feed = await parser.parseURL('https://www.cnbcindonesia.com/news/rss');

    if (!feed || !feed.items) throw new Error('Feed kosong atau tidak terbaca.');

    const items = feed.items.slice(0, 3);

    let teks = '*📰 Berita Indonesia Terkini:*\n\n';

    for (const item of items) {

      const title = item.title || '';

      const desc = item.contentSnippet || item.content || '';

      const link = item.link || '';

      teks += `*• ${title.trim()}*\n${desc.trim().slice(0, 200)}...\n🔗 ${link}\n\n`;

    }

    await sock.sendMessage(sender, { text: teks.trim(), quoted: key });

    await sock.sendMessage(sender, { react: { text: '✅', key } });

  } catch (err) {

    console.error('❌ NEWS ERROR:', err.message);

    await sock.sendMessage(sender, {

      text: '❌ Gagal mengambil berita:\n' + err.message,

      quoted: key

    });

  }

};