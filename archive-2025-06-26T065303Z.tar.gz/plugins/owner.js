module.exports = async function(sock, sender, command, key) {

    if (command.toLowerCase() !== 'owner') return;

    const nomorOwner = '6283850540570';

    await sock.sendMessage(sender, {

        image: {

            url: 'https://j.top4top.io/p_3463er6860.jpg' // Ganti dengan link gambar kamu

        },

        caption: '👑 *OWNER BOT*',

        footer: 'RIZKY APP STORE - Bot 24 Jam',

        buttons: [

            {

                buttonId: 'sewa',

                buttonText: { displayText: '🤖 Sewa Bot' },

                type: 1

            },

            {

                buttonId: 'beli',

                buttonText: { displayText: '💰 Beli Bot' },

                type: 1

            },

            {

                buttonId: `https://wa.me/${nomorOwner}`,

                buttonText: { displayText: '📱 Chat Admin' },

                type: 1

            }

        ],

        headerType: 4, // wajib untuk image+buttons

        quoted: key

    });

};