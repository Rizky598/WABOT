const pairingCount = new Map(); // Penyimpan limit pairing per nomor

module.exports = async function(sock, sender, command, key) {

    if (!command.toLowerCase().startsWith('pairing ')) return;

    const target = command.split(' ')[1]?.replace(/[^0-9]/g, '');

    if (!target) {

        return await sock.sendMessage(sender, {

            text: '❌ Masukkan nomor WhatsApp yang valid.\nContoh: pairing 6281234567890',

            quoted: key

        });

    }

    const limit = 3; // 🔒 Maksimum 3 pairing ke 1 nomor

    const cooldown = 60_000; // ⏱️ Waktu tunggu antar pairing (ms)

    const data = pairingCount.get(target) || { count: 0, last: 0 };

    // ✅ Cek limit dan cooldown

    if (data.count >= limit && Date.now() - data.last < cooldown) {

        return await sock.sendMessage(sender, {

            text: `⚠️ Pairing ke *${target}* sudah mencapai batas (${limit}x). Tunggu 1 menit sebelum mencoba lagi.`,

            quoted: key

        });

    }

    // 📡 Simulasi pairing (bisa disambungkan ke jadibot asli kalau mau)

    const kode = 'PAIR-' + Math.random().toString(36).substring(2, 8).toUpperCase();

    await sock.sendMessage(`${target}@s.whatsapp.net`, {

        text: `🤖 *PAIRING BOT*\n\nSeseorang mencoba pairing bot ke nomor ini.\nKode Pairing: *${kode}*\n\n⚠️ Abaikan jika bukan kamu.`

    });

    await sock.sendMessage(sender, {

        text: `✅ Pairing berhasil dikirim ke wa.me/${target}\nKode: *${kode}*`,

        quoted: key

    });

    // 🧠 Simpan state pairing ke Map

    pairingCount.set(target, {

        count: data.count + 1,

        last: Date.now()

    });

};