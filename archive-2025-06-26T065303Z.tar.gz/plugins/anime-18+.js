const axios = require('axios');

module.exports = async function(sock, sender, command, key, messageEvent) {

    try {

        // 1. React dengan ⏳ (proses)

        await sock.sendMessage(sender, {

            react: {

                text: '⏳',

                key: key

            }

        });

        // 2. Ambil gambar dari API

        const response = await axios.get('https://api.waifu.pics/nsfw/waifu');

        const imageUrl = response.data.url;

        // 3. Kirim gambar anime

        await sock.sendMessage(sender, {

            image: { url: imageUrl },

            caption: '*ini anime kesukaan lu lapet😹*'

        });

        // 4. Ganti react jadi ✅ (selesai)

        await sock.sendMessage(sender, {

            react: {

                text: '✅',

                key: key

            }

        });

    } catch (err) {

        console.error(err);

        // React ❌ jika gagal

        await sock.sendMessage(sender, {

            react: {

                text: '❌',

                key: key

            }

        });

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil gambar anime.'

        });

    }

};