const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

module.exports = async function(sock, sender, command, key) {
    if (command.toLowerCase() !== 'foto') return;

    const sumberFolder = path.join(__dirname, '../foto-asal');
    const tujuanFolder = path.join(__dirname, '../data/foto');

    if (!fs.existsSync(sumberFolder)) {
        return await sock.sendMessage(sender, {
            text: '❌ Folder foto-asal tidak ditemukan!',
            quoted: key
        });
    }

    if (!fs.existsSync(tujuanFolder)) {
        fs.mkdirSync(tujuanFolder, { recursive: true });
    }

    try {
        const files = fs.readdirSync(sumberFolder)
            .filter(file => /\.(jpg|jpeg|png)$/i.test(file))
            .sort();

        if (files.length === 0) {
            return await sock.sendMessage(sender, {
                text: '📂 Tidak ada foto yang ditemukan.',
                quoted: key
            });
        }

        const file = files[0];
        const asalPath = path.join(sumberFolder, file);
        const namaBaru = crypto.randomBytes(6).toString('hex') + path.extname(file);
        const tujuanPath = path.join(tujuanFolder, namaBaru);

        fs.renameSync(asalPath, tujuanPath);

        await sock.sendMessage(sender, {
            text: `✅ Foto dipindahkan sebagai: ${namaBaru}`,
            quoted: key
        });

    } catch (err) {
        console.error('PINDAH FOTO Error:', err.message);
        await sock.sendMessage(sender, {
            text: '❌ Gagal memindahkan foto.',
            quoted: key
        });
    }
};
