const axios = require('axios');

const lokasi = [

  { kota: 'Medan' },

  { kota: 'Padang' },

  { kota: 'Palembang' },

  { kota: 'Banda Aceh' }

];

async function getCuaca(kota) {

  try {

    const url = `https://wttr.in/${encodeURIComponent(kota)}?format=%C+%t`;

    const res = await axios.get(url);

    return res.data.trim(); // contoh: "Hujan Ringan +29°C"

  } catch {

    return 'Tidak tersedia';

  }

}

module.exports = async function(sock, sender, command, key) {

  await sock.sendMessage(sender, { react: { text: '⏳', key } });

  try {

    let teks = '*🌤️ Cuaca Hari Ini di Sumatera:*\n\n';

    for (const lokasiCuaca of lokasi) {

      const data = await getCuaca(lokasiCuaca.kota);

      teks += `📍 ${lokasiCuaca.kota}: ${data}\n`;

    }

    await sock.sendMessage(sender, { text: teks.trim(), quoted: key });

    await sock.sendMessage(sender, { react: { text: '✅', key } });

  } catch (e) {

    console.error('CUACA Error:', e.message);

    await sock.sendMessage(sender, {

      text: '❌ Gagal mengambil data cuaca.',

      quoted: key

    });

  }

};