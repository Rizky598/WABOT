module.exports = async function(sock, sender, command, key, message) {

    if (command.toLowerCase() !== 'bot') return;

    try {

        // ⏳ React loading

        await sock.sendMessage(sender, {

            react: { text: '⏳', key: key }

        });

        // 🎲 Acak salah satu link mp3

        const vnLinks = [

            'https://l.top4top.io/m_3463i5hgn3.mp3',

            'https://k.top4top.io/m_3463nwsqs2.mp3',

            'https://j.top4top.io/m_34630kefk1.mp3',

            'https://i.top4top.io/m_3463xpf300.mp3'

        ];

        const randomVN = vnLinks[Math.floor(Math.random() * vnLinks.length)];

        // 📹 Kirim video menu

        const menuText = `

 *🤖 Bot Rizky Aktif!*

*Silakan ketik (menu) untuk melihat fitur bot WhatsApp owner Rizky*
`;

        await sock.sendMessage(sender, {

            video: {

                url: 'https://i.top4top.io/m_34634pfqs0.mp4'

            },

            caption: menuText,

            mimetype: 'video/mp4',

            gifPlayback: true,

            mentions: [sender]

        });

        // 🎧 Kirim VN

        await sock.sendMessage(sender, {

            audio: {

                url: randomVN

            },

            mimetype: 'audio/mp4',

            ptt: true,

            quoted: key

        });

        // ✅ React selesai

        await sock.sendMessage(sender, {

            react: { text: '✅', key: key }

        });

    } catch (err) {

        console.error('AutoVN Error:', err.message);

        await sock.sendMessage(sender, {

            react: { text: '❌', key: key }

        });

        await sock.sendMessage(sender, {

            text: '❌ Gagal memproses respon.',

            quoted: key

        });

    }

};