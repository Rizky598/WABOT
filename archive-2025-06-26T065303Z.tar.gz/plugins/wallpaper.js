const axios = require('axios');

module.exports = async function(sock, sender, command, key) {

    if (command.toLowerCase() !== 'wallpaper') return;

    try {

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        const res = await axios.get('https://api.lolhuman.xyz/api/random/wallpaper?apikey=apikeymu');

        const imageUrl = res.data.result;

        await sock.sendMessage(sender, {

            image: { url: imageUrl },

            caption: '🖼️ Wallpaper estetik untukmu!',

            quoted: key

        });

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('WALLPAPER Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil wallpaper.',

            quoted: key

        });

    }

};