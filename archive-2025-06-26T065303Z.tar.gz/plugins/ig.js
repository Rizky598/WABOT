const axios = require('axios');

const cache = {}; // cache sementara link hasil scrape

module.exports = async function(sock, sender, command, key) {

    if (!command.toLowerCase().startsWith('ig ')) return;

    const url = command.split(' ')[1];

    if (!url || !url.includes('instagram.com')) {

        return await sock.sendMessage(sender, {

            text: '❌ Masukkan link Instagram yang valid.\nContoh:\nig https://www.instagram.com/reel/xyz',

            quoted: key

        });

    }

    try {

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        const res = await axios.get(`https://api.dlpanda.com/api/dl?url=${encodeURIComponent(url)}`);

        const result = res.data.result || res.data;

        if (!result || (!result.video && !result.audio)) throw new Error('Tidak ditemukan.');

        // simpan cache sementara

        cache[sender] = {

            video: result.video,

            audio: result.audio

        };

        // kirim tombol

        await sock.sendMessage(sender, {

            text: '📥 Pilih jenis media yang ingin kamu unduh:',

            buttons: [

                { buttonId: 'ig_video', buttonText: { displayText: '🎥 Download Video' }, type: 1 },

                { buttonId: 'ig_audio', buttonText: { displayText: '🎵 Download Audio' }, type: 1 }

            ],

            headerType: 1,

            quoted: key

        });

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('IG BUTTON Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil data dari Instagram.',

            quoted: key

        });

    }

    // respon tombol

    sock.ev.on('messages.upsert', async ({ messages }) => {

        const m = messages[0];

        if (!m.message?.buttonsResponseMessage) return;

        const id = m.message.buttonsResponseMessage.selectedButtonId;

        const media = cache[m.key.remoteJid];

        if (!media) return;

        if (id === 'ig_video') {

            await sock.sendMessage(m.key.remoteJid, {

                video: { url: media.video },

                mimetype: 'video/mp4',

                caption: '✅ Berikut videonya.'

            });

        } else if (id === 'ig_audio') {

            await sock.sendMessage(m.key.remoteJid, {

                audio: { url: media.audio },

                mimetype: 'audio/mp4',

                ptt: true

            });

        }

        delete cache[m.key.remoteJid]; // hapus cache biar tidak numpuk

    });

};