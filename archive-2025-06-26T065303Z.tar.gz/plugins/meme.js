const axios = require('axios');

module.exports = async function(sock, sender, command, key) {

    if (command.toLowerCase() !== 'meme') return;

    try {

        // ⏳ Reaksi mulai

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        const res = await axios.get('https://meme-api.com/gimme');

        const { url, title, postLink } = res.data;

        // Cek URL valid

        if (!url || !url.startsWith('http')) {

            throw new Error('URL gambar tidak valid');

        }

        await sock.sendMessage(sender, {

            image: { url },

            caption: `🤣 *${title}*\n🌐 ${postLink}`,

            quoted: key

        });

        // ✅ Reaksi selesai

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('MEME Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil meme lucu.',

            quoted: key

        });

    }

};