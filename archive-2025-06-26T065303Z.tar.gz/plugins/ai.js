const axios = require('axios');

module.exports = async function(sock, sender, command, key) {

    const teks = command.trim().toLowerCase();

    if (!teks.startsWith('ai ')) return;

    const prompt = teks.slice(3).trim();

    if (!prompt) {

        return await sock.sendMessage(sender, {

            text: `❌ Ketik sesuatu setelah "ai", contoh:\nai cewek anime imut`,

            quoted: key

        });

    }

    try {

        await sock.sendMessage(sender, { react: { text: '⏳', key } });

        const res = await axios.get(`https://api.lolhuman.xyz/api/dalle?apikey=apikeymu&text=${encodeURIComponent(prompt)}`);

        const imageUrl = res.data.result;

        await sock.sendMessage(sender, {

            image: { url: imageUrl },

            caption: `🧠 *Hasil AI dari prompt:*\n"${prompt}"`,

            quoted: key

        });

        await sock.sendMessage(sender, { react: { text: '✅', key } });

    } catch (err) {

        console.error('AI IMAGE Error:', err.message);

        await sock.sendMessage(sender, {

            text: '❌ Gagal mengambil gambar dari AI.',

            quoted: key

        });

    }

};