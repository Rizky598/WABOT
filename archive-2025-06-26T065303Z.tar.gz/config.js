

const numberAllowed = ['62895627520102','6283850540570']; // Nomor yang diizinkan untuk chat ke bot, tambahkan kalau diperlukan

global.prefix = ['.', '#']; // Daftar prefix

global.jeda = 8000; // 5 detik jeda pengiriman untuk pushkontak atau broadcast

global.name_script = '🤖ʙᴏᴛ ʀɪᴢᴋʏᴘᴜꜱʜx🤖';

global.version = '3.1';

module.exports = { numberAllowed };